from rest_framework.decorators import api_view
from rest_framework.response import Response
from .serializers import ProductSerializer
from .models import Product


@api_view(["GET"])
def getRoutes(request):
    routes = [
        {
            "Endpoint": "/ecom/",
            "method": "GET",
            "body": None,
            "description": "Returns an array of products",
        },
        {
            "Endpoint": "/ecom/id",
            "method": "GET",
            "body": None,
            "description": "Returns a single  product",
        },
        {
            "Endpoint": "/ecom/create/",
            "method": "POST",
            "body": {"body": ""},
            "description": "Creates a new product",
        },
        {
            "Endpoint": "/ecom/id/update/",
            "method": "PUT",
            "body": {"body": ""},
            "description": "Creates an existing product with data sen in ",
        },
        {
            "Endpoint": "/ecom/",
            "method": "DELETE",
            "body": None,
            "description": "Deletes an existing product",
        },
    ]
    return Response(routes)


@api_view(["GET"])
def getProducts(request):
    products = Product.objects.all()
    serializer = ProductSerializer(products, many=True)
    return Response(serializer.data)


@api_view(["GET"])
def getProduct(request, pk):
    products = Product.objects.get(id=pk)
    serializer = ProductSerializer(products, many=True)
    return Response(serializer.data)


@api_view(["POST"])
def createProduct(request):
    data = request.data
    product = Product.objects.create(name=data["name"])
    serializer = ProductSerializer(product, many=False)
    return Response(serializer.data)


@api_view(["PUT"])
def updateProduct(request, pk):
    data = request.data
    product = Product.objects.get(id=pk)
    serializer = ProductSerializer(product, data=request.POST)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data)
